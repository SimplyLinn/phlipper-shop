import {
  HEATSHRINK_MAX_WINDOW_BITS,
  HEATSHRINK_MIN_LOOKAHEAD_BITS,
  HEATSHRINK_MIN_WINDOW_BITS,
} from "./common.js";

enum HSD_state {
  HSDS_TAG_BIT /* tag bit */,
  HSDS_YIELD_LITERAL /* ready to yield literal byte */,
  HSDS_BACKREF_INDEX_MSB /* most significant byte of index */,
  HSDS_BACKREF_INDEX_LSB /* least significant byte of index */,
  HSDS_BACKREF_COUNT_MSB /* most significant byte of count */,
  HSDS_BACKREF_COUNT_LSB /* least significant byte of count */,
  HSDS_YIELD_BACKREF /* ready to yield back-reference */,
}

enum HSD_sink_res {
  HSDR_SINK_OK /* data sunk, ready to poll */,
  HSDR_SINK_FULL /* out of space in internal buffer */,
}

enum HSD_poll_res {
  HSDR_POLL_EMPTY /* input exhausted */,
  HSDR_POLL_MORE /* more data remaining, call again w/ fresh output buffer */,
}

enum HSD_finish_res {
  HSDR_FINISH_DONE /* output is done */,
  HSDR_FINISH_MORE /* more output remains */,
}

const NO_BITS = 0xffff;

class HeatshrinkDecoder {
  inputSize: number = 0;
  inputIndex: number = 0;
  outputCount: number = 0;
  outputIndex: number = 0;
  headIndex: number = 0;
  state: HSD_state = HSD_state.HSDS_TAG_BIT;
  currentByte: number = 0;
  bitIndex: number = 0;

  buffers: Uint8Array;

  /**
   * 
   * @param inputBufferSize The size of the input buffer in bytes
   * @param windowSize2 The square root of the window size (2^windowSize2)
   * @param lookaheadSize2 The square root of the lookahead size (2^lookaheadSize2)
   */
  constructor(
    public readonly inputBufferSize: number,
    public windowSize2: number,
    public lookaheadSizeSqrd: number
  ) {
    if (
      windowSize2 < HEATSHRINK_MIN_WINDOW_BITS ||
      windowSize2 > HEATSHRINK_MAX_WINDOW_BITS
    ) {
      throw new RangeError(
        `Invalid window size ${windowSize2}, must be between ${HEATSHRINK_MIN_WINDOW_BITS} and ${HEATSHRINK_MAX_WINDOW_BITS}`
      );
    }
    if (inputBufferSize == 0) {
      throw new RangeError("Input buffer size must be greater than 0");
    }
    if (
      lookaheadSizeSqrd < HEATSHRINK_MIN_LOOKAHEAD_BITS ||
      lookaheadSizeSqrd >= windowSize2
    ) {
      throw new RangeError(
        `Invalid lookahead size ${lookaheadSizeSqrd}, must be between ${HEATSHRINK_MIN_LOOKAHEAD_BITS} and windowSize${windowSize2}`
      );
    }
    this.buffers = new Uint8Array(inputBufferSize + (1 << windowSize2));
    this.reset();
  }

  reset() {
    this.state = HSD_state.HSDS_TAG_BIT;
    this.inputSize = 0;
    this.inputIndex = 0;
    this.bitIndex = 0;
    this.currentByte = 0;
    this.outputCount = 0;
    this.outputIndex = 0;
    this.headIndex = 0;
    this.buffers.fill(0);
  }

  static bufCpy(from: Uint8Array, fromIndex: number, to: Uint8Array, toIndex: number, length?: number) {
    if (length == null) {
      length = Math.min(from.length - fromIndex, to.length - toIndex);
    }
    for(let i = 0; i < length; i++) {
      to[toIndex + i] = from[fromIndex + i];
    }
  }

  sink(inBuf: Uint8Array): [result: HSD_sink_res, inputSize: number] {
    const remaining = this.inputBufferSize - this.inputSize;
    if (remaining <= 0) {
      return [HSD_sink_res.HSDR_SINK_FULL, 0];
    }
    const size = Math.min(inBuf.length, remaining);
    HeatshrinkDecoder.bufCpy(inBuf, 0, this.buffers, this.inputSize, size);
    this.inputSize += size;
    return [HSD_sink_res.HSDR_SINK_OK, size];
  }
}
