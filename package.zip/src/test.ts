import { readFileSync } from "node:fs";

const file = readFileSync("./NSFW/Anims/lvl_1/frame_0.bm");
for(let j = 0; j < 16; j++) {
  for(let i = 0; i < 64; i++) {
    const byte = file[j * 64 + i];
    for(let k = 0; k < 8; k++) {
      const bit = (byte >> k) & 1;
      process.stdout.write(bit ? "█" : " ");
    }
  }
  process.stdout.write("\n");
}